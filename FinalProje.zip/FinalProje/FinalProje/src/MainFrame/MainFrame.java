package MainFrame;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;

public class MainFrame extends JFrame implements ActionListener {
    FileOperations fileOperations = new FileOperations();
    DataOperations dataOperations = new DataOperations();
    DefaultListModel<String> classListModel = new DefaultListModel<>();
    JList<String> DosyaListesi = new JList<>(classListModel);
    JTextArea txtVeriBilgileri = new JTextArea();

    public MainFrame() {
        JFrame frame = new JFrame("Veri Dosya Yönetimi");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frame.setBackground(new Color(192,192,192));
        frame.setForeground(new Color(169,169,169));
        //////////SOL PANEL\\\\\\\\\\
        JPanel pnlSol = new JPanel();
        pnlSol.setBackground(new Color(192,192,192));
        pnlSol.setForeground(new Color(165,165,165));
        pnlSol.setLayout(new BoxLayout(pnlSol, BoxLayout.Y_AXIS));
        pnlSol.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));


        DosyaListesi.setBackground(new Color(224,224,224));


        JLabel lblBaslik1 = new JLabel("Dosya İşlemleri", SwingConstants.CENTER);
        lblBaslik1.setFont(new Font("Century Gothic", Font.BOLD, 30));
        pnlSol.add(lblBaslik1, BorderLayout.CENTER);

        pnlSol.add(Box.createRigidArea(new Dimension(0, 10)));

        updateClassList();
        pnlSol.add(new JScrollPane(DosyaListesi), BorderLayout.CENTER);

        frame.add(pnlSol, BorderLayout.WEST);


        JButton btnDosyaOlusturma = new JButton("Dosya Oluştur");
        JButton btnDosyaSilme = new JButton("Dosya Sil");
        JButton btnDosyaGuncelleme = new JButton("Dosya Güncelle");
        JButton btnDosyaAcma = new JButton("Seçili Dosyayı Aç");

        Color renkButon = new Color(153, 193, 221);
        btnDosyaOlusturma.setBackground(renkButon);
        btnDosyaSilme.setBackground(renkButon);
        btnDosyaGuncelleme.setBackground(renkButon);
        btnDosyaAcma.setBackground(renkButon);

        btnDosyaOlusturma.setForeground(new Color(13, 13, 14));
        btnDosyaSilme.setForeground(new Color(13, 13, 14));
        btnDosyaGuncelleme.setForeground(new Color(13, 13, 14));
        btnDosyaAcma.setForeground(new Color(13, 13, 14));
        pnlSol.add(btnDosyaOlusturma);
        pnlSol.add(btnDosyaSilme);
        pnlSol.add(btnDosyaGuncelleme);
        pnlSol.add(btnDosyaAcma);

        ImageIcon iconDosya = new ImageIcon("FinalProje/src/MainFrame/dosya_gorseli.png");
        Image imageDosya = iconDosya.getImage();
        frame.setIconImage(imageDosya);

        btnDosyaOlusturma.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                File createdFile = null;
                try {
                    createdFile = fileOperations.createFile();
                } catch (CustomException ex) {
                    throw new RuntimeException(ex);
                }
                if (createdFile != null) {
                    List<String> headers = fileOperations.getHeaders();
                    headers.add(0, "Satır No");  // Satır No ekleyin
                    try {
                        Files.write(createdFile.toPath(), (String.join("\t\t\t", headers) + "\n").getBytes(), StandardOpenOption.APPEND);
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                    updateClassList();
                    JOptionPane.showMessageDialog(frame, "Dosya oluşturuldu");
                }
            }
        });

        btnDosyaSilme.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    boolean deleted = fileOperations.deleteFile();
                    if (deleted) {
                        updateClassList();
                    } else {
                        throw new CustomException("Dosya silme hatası.");
                    }
                } catch (CustomException ex) {
                    JOptionPane.showMessageDialog(frame, "Hata: " + ex.getMessage());
                    ex.printStackTrace();
                }
            }
        });

        btnDosyaGuncelleme.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int result = fileOperations.renameFileName();
                    if (result == 1) {
                        updateClassList();
                    } else {
                        throw new CustomException("Dosya adı güncelleme hatası.");
                    }
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(frame, "Giriş/Çıkış hatası: " + ex.getMessage());
                    ex.printStackTrace();
                } catch (CustomException ex) {
                    JOptionPane.showMessageDialog(frame, "Hata: " + ex.getMessage());
                    ex.printStackTrace();
                }
            }
        });

        btnDosyaAcma.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String selectedFile = DosyaListesi.getSelectedValue();
                    if (selectedFile != null) {
                        openFilePanel(frame, selectedFile);
                    } else {
                        throw new CustomException("Lütfen bir dosya seçin.");
                    }
                } catch (CustomException ex) {
                    JOptionPane.showMessageDialog(frame, "Hata: " + ex.getMessage());
                    ex.printStackTrace();
                }
            }
        });

        frame.setVisible(true);
    }

    private void updateClassList() {
        classListModel.clear();
        File folder = new File(".");
        File[] listOfFiles = folder.listFiles((dir, name) -> name.endsWith(".txt"));
        if (listOfFiles != null) {
            for (File file : listOfFiles) {
                classListModel.addElement(file.getName());
            }
        }
    }

    private void openFilePanel(JFrame frame, String fileName) {
        frame.getContentPane().removeAll();

        JPanel pnlVeriler = new JPanel();
        pnlVeriler.setLayout(new BoxLayout(pnlVeriler, BoxLayout.Y_AXIS));
        pnlVeriler.setBackground(new Color(176, 196, 222));
        pnlVeriler.setVisible(true);

        JLabel lblDosyaAdi = new JLabel(fileName, SwingConstants.CENTER);
        lblDosyaAdi.setForeground(new Color(70, 130, 180));
        lblDosyaAdi.setFont(new Font("Century Gothic", Font.BOLD, 20));
        lblDosyaAdi.setAlignmentX(Component.CENTER_ALIGNMENT);
        pnlVeriler.add(lblDosyaAdi, BorderLayout.NORTH);

        txtVeriBilgileri = new JTextArea();
        txtVeriBilgileri.setEditable(false);
        pnlVeriler.add(new JScrollPane(txtVeriBilgileri), BorderLayout.CENTER);
        txtVeriBilgileri.setBackground(new Color(224, 255, 255));


        try {
            List<String> lines = Files.readAllLines(Path.of(fileName));
            for (String line : lines) {
                txtVeriBilgileri.append(line + "\n");
            }
        } catch (IOException ex) {
            throw new RuntimeException(new CustomException("Dosya okuma hatası: " + ex.getMessage(), ex));
        }


        JPanel pnlIslem = new JPanel();
        pnlIslem.setLayout(new GridLayout(2, 6));
        pnlIslem.setBackground(new Color(228, 3, 3));

        JButton btnEkle = new JButton("Veri Ekle");
        JButton btnSil = new JButton("Veri Sil");
        JButton btnGuncelle = new JButton("Veri Güncelle");
        JButton btnSutunEkle = new JButton("Sütun Ekle");
        JButton btnAra = new JButton("Veri Ara");
        JButton btnGeri = new JButton("Geri");


        ////////////Gorsel Ekleme \\\\\\\\\\\

        ImageIcon iconEkle = new ImageIcon("FinalProje/src/MainFrame/ekleme_gorseli.png");
        btnEkle.setIcon(iconEkle);
        btnEkle.setHorizontalTextPosition(SwingConstants.CENTER);
        btnEkle.setVerticalTextPosition(SwingConstants.BOTTOM);
        btnEkle.setHorizontalAlignment(SwingConstants.CENTER);
        btnEkle.setVerticalAlignment(SwingConstants.CENTER);
        /////////

        ImageIcon iconSil = new ImageIcon("FinalProje/src/MainFrame/sil_gorseli.png");
        btnSil.setIcon(iconSil);
        btnSil.setHorizontalTextPosition(SwingConstants.CENTER);
        btnSil.setVerticalTextPosition(SwingConstants.BOTTOM);
        btnSil.setHorizontalAlignment(SwingConstants.CENTER);
        btnSil.setVerticalAlignment(SwingConstants.CENTER);
        ////////
        ImageIcon iconGuncelle = new ImageIcon("FinalProje/src/MainFrame/guncelle_gorseli.png");
        btnGuncelle.setIcon(iconGuncelle);
        btnAra.setHorizontalTextPosition(SwingConstants.CENTER);
        btnAra.setVerticalTextPosition(SwingConstants.BOTTOM);
        btnAra.setHorizontalAlignment(SwingConstants.CENTER);
        btnAra.setVerticalAlignment(SwingConstants.CENTER);

        ////////
        ImageIcon iconSutun = new ImageIcon("FinalProje/src/MainFrame/sutun_gorseli.png");
        btnSutunEkle.setIcon(iconSutun);
        btnSutunEkle.setHorizontalTextPosition(SwingConstants.CENTER);
        btnSutunEkle.setVerticalTextPosition(SwingConstants.BOTTOM);
        btnSutunEkle.setHorizontalAlignment(SwingConstants.CENTER);
        btnSutunEkle.setVerticalAlignment(SwingConstants.CENTER);

        ////////
        ImageIcon iconAra = new ImageIcon("FinalProje/src/MainFrame/arama_gorseli.png");
        btnAra.setIcon(iconAra);
        btnAra.setHorizontalTextPosition(SwingConstants.CENTER);
        btnAra.setVerticalTextPosition(SwingConstants.BOTTOM);
        btnAra.setHorizontalAlignment(SwingConstants.CENTER);
        btnAra.setVerticalAlignment(SwingConstants.CENTER);

        ////////

        ImageIcon iconGeri = new ImageIcon("FinalProje/src/MainFrame/geri_gorseli.png");
        btnGeri.setIcon(iconGeri);
        btnGeri.setHorizontalTextPosition(SwingConstants.CENTER);
        btnGeri.setVerticalTextPosition(SwingConstants.BOTTOM);
        btnGeri.setHorizontalAlignment(SwingConstants.CENTER);
        btnGeri.setVerticalAlignment(SwingConstants.CENTER);

        btnGeri.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btnGeri.setBackground(Color.RED);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                btnGeri.setBackground(new Color(176, 196, 222));

            }
        });

        ///////////

        pnlIslem.add(btnGeri);
        pnlIslem.add(btnEkle);
        pnlIslem.add(btnGuncelle);
        pnlIslem.add(btnSil);
        pnlIslem.add(btnSutunEkle);
        pnlIslem.add(btnAra);


        pnlVeriler.add(pnlIslem, BorderLayout.SOUTH);
        frame.getContentPane().add(pnlVeriler);

        JSplitPane paneBolucu = new JSplitPane(JSplitPane.VERTICAL_SPLIT, pnlVeriler, pnlIslem);
        paneBolucu.setResizeWeight(0.75);
        paneBolucu.setDividerSize(0);
        paneBolucu.setEnabled(false);
        frame.add(paneBolucu);


        ////// Veri Ekleme Butonu \\\\\
        btnEkle.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    List<String> headers = new ArrayList<>();
                    Path path = Path.of(fileName);
                    List<String> lines = Files.readAllLines(path);
                    if (!lines.isEmpty()) {
                        String[] headerLine = lines.get(0).split("\t\t\t");
                        for (String header : headerLine) {
                            headers.add(header);
                        }
                    }

                    while (true) {
                        dataOperations.addDataInfo(headers, fileName.replace(".txt", ""));
                        String choice = JOptionPane.showInputDialog("Başka veri bilgisi eklemek istiyor musunuz? (E/H)");
                        if (!choice.equalsIgnoreCase("E")) {
                            break;
                        }
                    }

                    JOptionPane.showMessageDialog(frame, "Veri eklendi.");
                    openFilePanel(frame, fileName);
                } catch (IOException ex) {
                    throw new RuntimeException(new CustomException("Veri ekleme hatası: " + ex.getMessage(), ex));
                }
            }
        });


        ////// Veri Silme Butonu \\\\\
        btnSil.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    dataOperations.deleteDataInfo(fileName);
                    // Satır numaralarını güncelle
                    updateLineNumbers(fileName);

                    JOptionPane.showMessageDialog(frame, "Veri silindi.");
                    openFilePanel(frame, fileName); // To refresh the content
                } catch (IOException ex) {
                    throw new RuntimeException(new CustomException("Veri silme hatası: " + ex.getMessage(), ex));
                }
            }
        });

        ////// Veri Güncelleme Butonu \\\\\
        btnGuncelle.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    dataOperations.updateDataInfo(fileName);
                    JOptionPane.showMessageDialog(frame, "Veri bilgisi güncellendi.");
                    openFilePanel(frame, fileName); // İçeriği yenilemek için
                } catch (IOException ex) {
                    throw new RuntimeException(new CustomException("Veri güncelleme hatası: " + ex.getMessage(), ex));
                }
            }
        });


        ////// Sütun Ekleme Butonu \\\\\
        btnSutunEkle.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    dataOperations.addColumn(fileName);
                    JOptionPane.showMessageDialog(frame, "Sütun eklendi.");
                    openFilePanel(frame, fileName); // To refresh the content
                } catch (IOException ex) {
                    throw new RuntimeException(new CustomException("Sütun ekleme hatası: " + ex.getMessage(), ex));
                }
            }
        });

        ////// Geri Dönüş Butonu \\\\\
        btnGeri.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.getContentPane().removeAll();
                new MainFrame();
                frame.revalidate();
                frame.repaint();
            }
        });

        ////// Arama Butonu \\\\\
        btnAra.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String searchText = JOptionPane.showInputDialog("Aranacak metni girin:");
                    List<Integer> foundLines = dataOperations.searchInFile(fileName, searchText);

                    if (foundLines.isEmpty()) {
                        JOptionPane.showMessageDialog(frame, "Aranan metin bulunamadı.");
                    } else {
                        JOptionPane.showMessageDialog(frame, "Aranan metin " + foundLines.size() + " satırda bulundu: " + foundLines);
                    }
                } catch (IOException ex) {
                    throw new RuntimeException(new CustomException("Arama hatası: " + ex.getMessage(), ex));
                }
            }
        });

        frame.revalidate();
        frame.repaint();
    }

    private void updateLineNumbers(String fileName) throws IOException {
        Path path = Path.of(fileName);
        List<String> lines = Files.readAllLines(path);
        List<String> updatedLines = new ArrayList<>();


        if (!lines.isEmpty()) {
            updatedLines.add(lines.get(0));
        }


        for (int i = 1; i < lines.size(); i++) {
            String[] columns = lines.get(i).split("\t\t\t");
            columns[0] = String.valueOf(i);
            updatedLines.add(String.join("\t\t\t", columns));
        }

        Files.write(path, updatedLines);
    }


    @Override
    public void actionPerformed(ActionEvent e) {

    }
}
