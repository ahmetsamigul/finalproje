package MainFrame;

import javax.swing.*;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class FileOperations {
    private String fileName;
    private List<String> headers = new ArrayList<>();
    public List<String> getHeaders() {
        return headers;
    }

    public void setHeaders() {
        while (true) {
            String header = JOptionPane.showInputDialog("Bilgi başlığı girin (örneğin Ad, Soyad, No):");
            if (header != null && !header.isEmpty()) {
                headers.add(header);
                String choice = JOptionPane.showInputDialog("Başka başlık eklemek istiyor musunuz? (E/H)");
                if (!choice.equalsIgnoreCase("E")) {
                    break;
                }
            } else {
                JOptionPane.showMessageDialog(null, "Geçerli bir başlık girin.");
            }
        }
    }

    public File createFile() throws CustomException {
        fileName = JOptionPane.showInputDialog("Dosya adı girin:");
        if (fileName != null && !fileName.isEmpty()) {
            fileName += ".txt";
            File file = new File(fileName);
            if (!file.exists()) {
                try {
                    if (file.createNewFile()) {
                        setHeaders();
                        return file;
                    }
                } catch (IOException ex) {
                    throw new CustomException("Dosya yazma hatası: " + ex.getMessage(), ex);
                }
            } else {
                JOptionPane.showMessageDialog(null, "Dosya zaten mevcut.");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Geçerli bir dosya adı girin.");
        }
        return null;
    }

    public boolean deleteFile() {
        String fileToDelete = JOptionPane.showInputDialog("Silmek istediğiniz dosyanın adını girin:");
        if (fileToDelete != null && !fileToDelete.isEmpty()) {
            File file = new File(fileToDelete + ".txt");
            if (file.exists()) {
                if (file.delete()) {
                    JOptionPane.showMessageDialog(null, "Dosya silindi.");
                    return true;
                } else {
                    JOptionPane.showMessageDialog(null, "Dosya silinemedi.");
                }
            } else {
                JOptionPane.showMessageDialog(null, "Dosya bulunamadı.");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Geçerli bir dosya adı girin.");
        }
        return false;
    }

    public int renameFileName() throws IOException {
        String oldFileName = JOptionPane.showInputDialog("Güncellemek istediğiniz dosyanın adını girin:");
        String newFileName = JOptionPane.showInputDialog("Yeni dosya adını girin:");
        if (oldFileName != null && newFileName != null && !oldFileName.isEmpty() && !newFileName.isEmpty()) {
            File oldFile = new File(oldFileName + ".txt");
            File newFile = new File(newFileName + ".txt");
            if (oldFile.exists() && !newFile.exists()) {
                if (oldFile.renameTo(newFile)) {
                    JOptionPane.showMessageDialog(null, "Dosya adı güncellendi.");
                    return 1;
                } else {
                    JOptionPane.showMessageDialog(null, "Dosya adı güncellenemedi.");
                }
            } else {
                JOptionPane.showMessageDialog(null, "Dosya bulunamadı veya yeni dosya adı zaten mevcut.");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Geçerli dosya adları girin.");
        }
        return 0;
    }



}
