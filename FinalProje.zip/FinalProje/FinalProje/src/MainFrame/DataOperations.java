package MainFrame;

import javax.swing.*;
import java.io.IOException;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;

public class DataOperations {

    public void addDataInfo(List<String> headers, String className) throws IOException {
        List<String> studentInfo = new ArrayList<>();
        String fileName = className + ".txt";

        Path path = Path.of(fileName);
        List<String> lines = Files.readAllLines(path);
        int lineNumber = lines.size();


        studentInfo.add(String.valueOf(lineNumber));

        for (int i = 1; i < headers.size(); i++) {
            String info = JOptionPane.showInputDialog(headers.get(i) + " bilgisini girin:");
            studentInfo.add(info);
        }

        String studentLine = String.join("\t\t\t", studentInfo);
        Files.write(path, (studentLine + "\n").getBytes(), StandardOpenOption.APPEND);
    }

    public void deleteDataInfo(String fileName) throws IOException {
        Path path = Path.of(fileName);
        List<String> lines = Files.readAllLines(path);

        if (lines.size() <= 1) {
            JOptionPane.showMessageDialog(null, "Dosya boş veya sadece başlık içeriyor, silinecek veri yok.");
            return;
        }

        String studentNo = JOptionPane.showInputDialog("Silmek istediğiniz verinin satır numarasını girin:");
        int lineNumber = Integer.parseInt(studentNo);

        if (lineNumber <= 0 || lineNumber >= lines.size()) {
            JOptionPane.showMessageDialog(null, "Geçersiz satır numarası.");
            return;
        }

        lines.remove(lineNumber);

        Files.write(path, lines);
    }

    public void updateDataInfo(String fileName) throws IOException {
        Path path = Path.of(fileName);
        List<String> lines = Files.readAllLines(path);

        if (lines.size() <= 1) {
            JOptionPane.showMessageDialog(null, "Dosya boş veya sadece başlık içeriyor, güncellenecek veri yok.");
            return;
        }

        String studentNo = JOptionPane.showInputDialog("Güncellemek istediğiniz verinin satır numarasını girin:");
        int lineNumber = Integer.parseInt(studentNo);

        if (lineNumber <= 0 || lineNumber >= lines.size()) {
            JOptionPane.showMessageDialog(null, "Geçersiz satır numarası.");
            return;
        }

        String[] studentData = lines.get(lineNumber).split("\t\t\t");
        String[] headers = lines.get(0).split("\t\t\t");

        List<String> updatedStudentData = new ArrayList<>();
        updatedStudentData.add(studentData[0]);

        for (int i = 1; i < headers.length; i++) {
            String oldData = i < studentData.length ? studentData[i] : "";
            String newData = JOptionPane.showInputDialog(headers[i] + " (Eski Değer: " + oldData + ") Yeni Değeri Girin:");
            if (newData != null && !newData.trim().isEmpty()) {
                updatedStudentData.add(newData);
            } else {
                updatedStudentData.add(oldData);
            }
        }

        lines.set(lineNumber, String.join("\t\t\t", updatedStudentData));
        Files.write(path, lines);
    }


    public void addColumn(String fileName) throws IOException {
        Path path = Path.of(fileName);
        List<String> lines = Files.readAllLines(path);

        String newColumn = JOptionPane.showInputDialog("Yeni sütunun başlığını girin:");

        if (newColumn == null || newColumn.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Geçersiz sütun adı.");
            return;
        }

        for (int i = 0; i < lines.size(); i++) {
            if (i == 0) {
                lines.set(i, lines.get(i) + "\t\t\t" + newColumn);
            } else {
                lines.set(i, lines.get(i) + "\t\t\t");
            }
        }

        Files.write(path, lines);
    }


    public List<Integer> searchInFile(String fileName, String searchText) throws IOException {
        Path path = Path.of(fileName);
        List<String> lines = Files.readAllLines(path);
        List<Integer> foundLines = new ArrayList<>();

        for (int i = 0; i < lines.size(); i++) {
            if (lines.get(i).contains(searchText)) {
                foundLines.add(i);
            }
        }

        return foundLines;
    }
}
